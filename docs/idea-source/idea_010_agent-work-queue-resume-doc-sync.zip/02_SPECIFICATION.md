# 02 仕様: エージェント作業キュー・再開ノート・文書同期

## プロダクト範囲

- 領域: ProjectManagement
- リポジトリ名: agent-work-queue-resume-doc-sync
- 分野: エージェント作業管理
- 目標: 次の課題を軽減する: エージェント作業の前提、完了条件、次に読む文書がチャットに残り、次回セッションで失われやすい。
- 差別化ポイント: エージェントに渡す入力、作業結果、再開条件、文書更新を同じ管理単位にする。

## 主要フロー

1. ユーザーが入力データ、ファイル、ページ文脈、オブジェクト、作業項目を選択する。
2. システムがメタデータ、状態、候補を読み取り、正規化する。
3. ユーザーが設定、フィルター、対象、プリセットを調整する。
4. システムが処理、検証、比較、生成、保存のいずれかを実行する。
5. システムが結果、ログ、警告、次の操作を表示する。
6. ユーザーが書き出し、保存、再試行、スキップ、レビュー完了のいずれかを行う。

## 画面 / 操作面

- ダッシュボード: 現在の対象、状態、警告、次の操作を表示する。
- ワークベンチ: 入力、プレビュー、設定、実行、結果確認を扱う。
- 履歴: 実行ログ、判断、失敗、出力先を記録する。
- 設定: プリセット、出力先、権限、連携設定を管理する。

## データモデル案

| エンティティ | 主な項目 | 目的 |
| --- | --- | --- |
| Project | id, name, rootPath, createdAt, updatedAt | 作業単位 |
| Item | id, title, sourcePath, tags, status, metadata | 対象項目 |
| Preset | id, name, settings, targetType | 再利用可能な設定 |
| RunLog | id, itemId, action, result, errors, createdAt | 実行証跡 |
| Export | id, runId, outputPath, format, checksum | 出力管理 |

## エラー

- EmptyInput: 入力または対象が見つからない。
- InvalidFormat: 未対応または破損した入力。
- PermissionDenied: ファイル、API、ホストアプリの権限が不足している。
- PartialFailure: 一部の項目が失敗した。
- CompletedWithWarnings: 警告付きで完了した。
