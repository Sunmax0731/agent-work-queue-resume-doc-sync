あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Apps
- 領域: ProjectManagement
- No.: 10
- 分野: エージェント作業管理
- アイデア: エージェント作業キュー・再開ノート・文書同期
- リポジトリ名: agent-work-queue-resume-doc-sync

## 元アイデア

- 概要: Codexなどのエージェントへ渡す作業キュー、担当範囲、期待成果物、再開ノート、Issueとローカル文書の同期をまとめる。
- 課題: エージェント作業の前提、完了条件、次に読む文書がチャットに残り、次回セッションで失われやすい。
- 類似サービス・アプリ: Codex, Claude Code, Cursor, GitHub Issues, Notion
- 差別化ポイント: エージェントに渡す入力、作業結果、再開条件、文書更新を同じ管理単位にする。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- 主要ユーザー、ローカル保存、権限、バックアップ、外部API境界を明確にする。
- 入力から確認、履歴、出力までの一連の流れを設計する。
- 日常利用フロー、データ復旧、プライバシーに関わる挙動を検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
