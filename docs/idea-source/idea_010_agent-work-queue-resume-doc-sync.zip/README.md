# エージェント作業キュー・再開ノート・文書同期 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 10 |
| 分野 | エージェント作業管理 |
| アイデア | エージェント作業キュー・再開ノート・文書同期 |
| リポジトリ名 | agent-work-queue-resume-doc-sync |
| 概要 | Codexなどのエージェントへ渡す作業キュー、担当範囲、期待成果物、再開ノート、Issueとローカル文書の同期をまとめる。 |
| 課題 | エージェント作業の前提、完了条件、次に読む文書がチャットに残り、次回セッションで失われやすい。 |
| 類似サービス・アプリ | Codex, Claude Code, Cursor, GitHub Issues, Notion |
| 差別化ポイント | エージェントに渡す入力、作業結果、再開条件、文書更新を同じ管理単位にする。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `エージェント作業キュー・再開ノート・文書同期` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
